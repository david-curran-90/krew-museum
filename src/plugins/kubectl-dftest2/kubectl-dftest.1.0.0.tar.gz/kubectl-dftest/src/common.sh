#! /bin/bash

function result {
    # print the result of the test
    # arg 1 is the function name
    # arg 2 is the result [FAIL|PASS]
    # Outputs "test name - PASS"
    if [ "$1" ]; then 
        if [[ "$2" == "PASS" ]]; then
            R=$PASS
        elif [[ "$2" == "FAIL" ]]; then
            R=$FAIL
        else
            R=FAIL
            1="Unkown result type $2, must be one of [FAIL|PASS] - $1"
        fi
        # take the _ out to get the test name
        # equivilent to `echo $1 | sed's/_/ /g'`
        testname="${1//_/ }"
        if [[ $DEBUG == true ]]; then        
            printf "%s - %b%s%b\n" "$testname" "$R" "$2" "$NC"
        fi
        echo "$(date) $testname - $2" >> "$logfile"
    else
        printf "%b Bad argument result unknown%b\n" "${ERROR}" "${NC}"
    fi
}

function run_generic_test {
    # generic function to run a test
    # it simply checks if the command is successful ($?=0)
    # and returns PASS/FAIL
    # arg1 is the test to run
    # arg2 is the function it comes from
    if [[ $DEBUG == true ]]; then
        echo "$(date) Running $2 " >> "$logfile"
        cmd="$1 | tail -5 &>> $logfile"
    else
        cmd="$1 &> /dev/null"
    fi
    if ! eval "$cmd" ; then
        R="FAIL"
        ((FAILED++))
    else
        R="PASS"
        ((PASSED++))
    fi
    result "$2" "$R"
}

function applyManifest {
    # funcion to apply a manifest
    # runs kubectl apply -f $arg1
    # arg1 is the manifest to apply
    # arg2 is the calling function
    if [[ -f "$1" ]]; then
        DEPLOY_RUN=true
        TEST="$KUBECTL -n $ns apply -f $1"
        run_generic_test "$TEST" "$2"
    else
        DEPLOY_RUN=false
        msg="FAILED - couldn't find manifest file $1 for deployment"
        if [[ $DEBUG == true ]]; then
            printf "%s - %bFAIL%b\n" "$2" "$FAIL" "$NC"
        fi
        echo "$(date) $2 $msg" >> "$logfile"
        ((NORUN++))
    fi
}