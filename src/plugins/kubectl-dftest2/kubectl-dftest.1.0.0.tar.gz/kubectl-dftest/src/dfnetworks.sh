#! /bin/bash

source "$DIR/common.sh"

npservicename="test-nodeport-svc"
cpservicename="test-clusterip-svc"


########################
## KUBERNETES NETWORK ##
########################

function apply_ingress {
    igmanifest="$DIR/manifests/ingress.yaml"
    applyManifest "$igmanifest" "${FUNCNAME[0]}"
}

function get_ingress {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns get ingress --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingress didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingress" >> $logfile
    fi
}

function describe_ingress {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns describe ingress --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingress didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingress" >> $logfile
    fi
}

function delete_ingress {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns delete -f $igmanifest"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingress didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingress" >> $logfile
    fi
}

function create_service_nodeport {
    TEST="$KUBECTL -n $ns create service nodeport $npservicename --tcp=5678:8080"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function delete_service_nodeport {
    TEST="$KUBECTL -n $ns delete service $npservicename"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function create_service_clusterip {
    TEST="$KUBECTL -n $ns create service clusterip $cpservicename --tcp=5678:8080"
    run_generic_test "$TEST" "${FUNCNAME[0]}"    
}

function delete_service_clusterip {
    TEST="$KUBECTL -n $ns delete service $cpservicename"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function get_services {
    TEST="$KUBECTL get services --all-namespaces"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

#############
## Traefik ##
#############

function apply_ingressroute {
    irmanifest="$DIR/manifests/ingress_route.yaml"
    applyManifest "$irmanifest" "${FUNCNAME[0]}"
}

function get_ingressroute {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns get ingressroute --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingressroute didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingressroute" >> $logfile
    fi
}

function describe_ingressroute {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns describe ingressroute --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingressroute didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingressroute" >> $logfile
    fi
}

function delete_ingressroute {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns delete -f $irmanifest"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_ingressroute didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_ingressroute" >> $logfile
    fi
}


function network_tests {
    echo "Running network tests"
    create_service_nodeport
    delete_service_nodeport
    create_service_clusterip
    delete_service_clusterip
    get_services
    apply_ingress
    get_ingress
    describe_ingress
    delete_ingress
    apply_ingressroute
    get_ingressroute
    describe_ingressroute
    delete_ingressroute
    #create_middleware
    #get_middleware
    #describe_middleware
    #delete_middleware
    #check_dnsresolve
    #check_podconnection
}