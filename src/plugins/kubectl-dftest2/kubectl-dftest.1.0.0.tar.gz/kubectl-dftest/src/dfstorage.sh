#! /bin/bash

source "$DIR"/common.sh

#################
## STATEFULSET ##
#################

function apply_statefulset {
    # even though this is a workload it's heavy reliance on storage
    # means that I've put it in this script
    stmanifest="$DIR/manifests/statefulset.yaml"
    applyManifest "$stmanifest" "${FUNCNAME[0]}"
}

function get_statefulset {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns get statefulset --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_statefulset didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_statefulset" >> $logfile
    fi
}

function describe_statefulset {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns describe statefulset --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_statefulset didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_statefulset" >> $logfile
    fi
}

function delete_statefulset {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns delete -f $stmanifest"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_statefulset didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_statefulset" >> $logfile
    fi
}

#############
## STORAGE ##
#############

function apply_storageclass {
    scmanifest="$DIR/manifests/storageclass.yaml"
    applyManifest "$scmanifest" "${FUNCNAME[0]}"
}

function get_storageclass {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL get storageclass --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_storageclass didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_storageclass" >> $logfile
    fi
}

function describe_storageclass {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL describe storageclass --selector app=k8s-testing"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_statefulset didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_storageclass" >> $logfile
    fi
}

function delete_storageclass {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL delete -f $scmanifest"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_statefulset didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_statefulset" >> $logfile
    fi
}

function storage_tests {
    echo "Running storage tests"
    #apply_pvc
    #delete_pvc
    apply_statefulset
    get_statefulset
    describe_statefulset
    delete_statefulset
    #delete_pv
    apply_storageclass
    get_storageclass
    describe_storageclass
    delete_storageclass
}