#! /bin/bash

source "$DIR/common.sh"

#################
## DEPLOYMENTS ##
#################

function get_deployments {
    TEST="$KUBECTL get deployments --all-namespaces"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function describe_deployments {
    TEST="$KUBECTL describe deployments --all-namespaces"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function apply_deployments {
    manifest="$DIR/manifests/deployment.yaml"
    applyManifest "$manifest" "${FUNCNAME[0]}"
}

function delete_deployments {
    if [[ $DEPLOY_RUN == true ]]; then
        TEST="$KUBECTL -n $ns delete -f $manifest"
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    else
        ((NORUN++))
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_deployment didn't run\n" "${FUNCNAME[0]}"
        fi
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_deployments" >> $logfile
    fi
}

##########
## PODS ##
##########

function get_pod {
    if [[ $DEPLOY_RUN == false ]]; then
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_deployment didn't run\n" "${FUNCNAME[0]}"
        fi
        ((NORUN++))
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_deployments" >> $logfile
    else
        TEST="$KUBECTL -n $ns get pods -o name --selector app=k8s-testing"
        if pod=$(eval "$TEST"); then
            if [[ $DEBUG == true ]]; then
                echo "$(date) ${FUNCNAME[0]} found pod $pod" >> $logfile
            fi
            GET_POD=true
        else
            GET_POD=false
        fi
        run_generic_test "$TEST" "${FUNCNAME[0]}"
    fi
}

function exec_pod {
    if [[ $DEPLOY_RUN == false ]]; then
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_deployment didn't run\n" "${FUNCNAME[0]}"
        fi
        ((NORUN++))
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_deployments" >> $logfile
    else
        if
            if [[ $DEBUG == true ]]; then echo $pod >> logfile ; fi
            [[ $GET_POD == true ]] ; then
            TEST="$KUBECTL -n $ns exec $pod -- /bin/ls"
            run_generic_test "$TEST" "${FUNCNAME[0]}"
        else
            if [[ $DEBUG == true ]]; then
                printf "%b%s - assuming fail due to get pod failing%b\n" "$ERROR" "${FUNCNAME[0]}" "$NC"
            fi
            echo "$(date) ${FUNCNAME[0]} failed due to failed get_pod" >> "$logfile"
            ((FAILED++))
        fi
    fi
}

function logs_pod {
    if [[ $DEPLOY_RUN == false ]]; then
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_deployment didn't run\n" "${FUNCNAME[0]}"
        fi
        ((NORUN++))
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_deployments" >> $logfile
    else
        if [[ $GET_POD == true ]] ; then
            TEST="$KUBECTL -n $ns logs $pod | tail"
            run_generic_test "$TEST" "${FUNCNAME[0]}"
        else
            if [[ $DEBUG == true ]]; then
                printf "%b%s - assuming fail due to get pod failing%b\n" "$ERROR" "${FUNCNAME[0]}" "$NC"
            fi
            echo "$(date) ${FUNCNAME[0]} failed due to failed get_pod" >> "$logfile"
            ((FAILED++))
        fi
    fi
}

function delete_pod {
    if [[ $DEPLOY_RUN == fale ]]; then
        if [[ $DEBUG == true ]]; then
            printf "%s - not running as apply_deployment didn't run\n" "${FUNCNAME[0]}"
        fi
        ((NORUN++))
        echo "$(date) Not running ${FUNCNAME[0]} due to failed apply_deployments" >> $logfile
    else
        if [[ $GET_POD == true ]] ; then
            TEST="$KUBECTL -n $ns delete $pod"
            run_generic_test "$TEST" "${FUNCNAME[0]}"
        else
            if [[ $DEBUG == true ]]; then
                printf "%b%s - assuming fail due to get pod failing%b\n" "$ERROR" "${FUNCNAME[0]}" "$NC"
            fi
            echo "$(date) ${FUNCNAME[0]} failed due to failed get_pod" >> "$logfile"
            ((FAILED++))
        fi
    fi
}

############
## CONFIG ##
############

function create_configmap {
    TEST="$KUBECTL -n $ns create configmap test-conf --from-literal=data=value"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function delete_configmap {
    TEST="$KUBECTL -n $ns delete configmap test-conf"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function create_secret {
    TEST="$KUBECTL -n $ns create secret generic test-secret --from-literal=secret=shhh"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function delete_secret {
    TEST="$KUBECTL -n $ns delete secret test-secret"
    run_generic_test "$TEST" "${FUNCNAME[0]}"
}

function workload_tests {
    echo "Running workload tests"
    get_deployments
    describe_deployments
    apply_deployments
    # hacky waiting for pod to start up
    # TODO: clean this hack up
    sleep 20
    get_pod
    logs_pod
    exec_pod
    delete_pod
    create_configmap
    delete_configmap
    create_secret
    delete_secret
    delete_deployments
}